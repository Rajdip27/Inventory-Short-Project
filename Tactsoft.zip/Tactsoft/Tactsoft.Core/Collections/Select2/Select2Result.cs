﻿namespace Tactsoft.Core.Collections.Select2
{
    public class Select2Result
    {
        public string id { get; set; }

        public string text { get; set; }
    }
}