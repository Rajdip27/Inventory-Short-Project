﻿namespace Tactsoft.Core.Collections
{
    public class IDropdown<T>
    {
        public IList<T> Data { get; set; }
    }
}
